package com.example.h_bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    float height,weight;
    EditText height_txt,weight_txt;
    Button calc , reset;

    TextView bmi_txt ,risk,category;

    private static DecimalFormat df = new DecimalFormat("0.0");
    SharedPreferences sharedPref;

    CardView cardView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        height_txt = findViewById(R.id.height);
        weight_txt = findViewById(R.id.weight);
        calc = findViewById(R.id.calculate);
        reset = findViewById(R.id.reset);

        bmi_txt = findViewById(R.id.bmi);
        risk = findViewById(R.id.risk);
        category = findViewById(R.id.category);

        cardView = findViewById(R.id.cardView);

        sharedPref = this.getSharedPreferences("height", Context.MODE_PRIVATE);
        sharedPref = this.getSharedPreferences("weight", Context.MODE_PRIVATE);

        float hg = sharedPref.getFloat("height", 0);
        float wg = sharedPref.getFloat("weight", 0);
        height_txt.setText((String.valueOf(hg)));
        weight_txt.setText((String.valueOf(wg)));

        cardView.setVisibility(View.GONE);

        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    CalcBMI();
                    cardView.setVisibility(View.VISIBLE);

                } catch (Exception exception) {

                    Toast.makeText(MainActivity.this, "Please enter your height or weight", Toast.LENGTH_SHORT).show();
                }

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                reset();

            }
        });

    }



    private void reset() {

        float reset = 0;

        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putFloat("height", reset);
        editor.putFloat("weight", reset);
        editor.apply();

        height_txt.setText("");
        weight_txt.setText("");

    }


    private void CalcBMI() {


        height = Float.parseFloat(height_txt.getText().toString());
        float heightincm;
        heightincm = height / 100;
        weight =Float.parseFloat(weight_txt.getText().toString());

        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putFloat("height", height);
        editor.putFloat("weight", weight);
        editor.apply();

        float bmi = weight / (heightincm*heightincm);
        String cm  = df.format(bmi);
        bmi_txt.setText(cm);

        if (bmi < 18.5) {
            category.setText("Underweight");
            risk.setText("Malnutrition Risk");

        } else if (bmi >=18.5 && bmi < 25) {
            category.setText("Normal Weight");
            risk.setText("Low Risk");

        } else if (bmi >=25 && bmi < 30) {
            category.setText("Overweight");
            risk.setText("Enhanced Risk");

        } else if (bmi >=30 && bmi < 35) {
            category.setText("Moderately Obese");
            risk.setText("Medium Risk");

        } else if (bmi >=35 && bmi <= 40) {
            category.setText("Severely Obese");
            risk.setText("High Risk");

        }  else {
            category.setText("Very Severely Obese");
            risk.setText("Very High Risk");

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.profile:
                startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


}